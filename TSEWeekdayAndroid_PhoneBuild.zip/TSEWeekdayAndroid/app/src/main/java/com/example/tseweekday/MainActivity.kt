package com.example.tseweekday

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var symbolsInput: EditText
    private lateinit var periodSpinner: Spinner
    private lateinit var runButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var resultView: TextView
    private lateinit var statusView: TextView

    private val weekdays = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه")
    private val weekdayOrder = mapOf(
        DayOfWeek.SATURDAY to 0,
        DayOfWeek.SUNDAY to 1,
        DayOfWeek.MONDAY to 2,
        DayOfWeek.TUESDAY to 3,
        DayOfWeek.WEDNESDAY to 4
    )

    data class QuoteDay(
        val date: LocalDate,
        val symbol: String,
        val close: Double,
        val previous: Double
    ) {
        val ret: Double get() = (close / previous - 1.0) * 100.0
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFFF7F8FA.toInt())
        }

        val title = TextView(this).apply {
            text = "تحلیلگر روزهای بورس ایران"
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF172B4D.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }
        layout.addView(title)

        val explanation = TextView(this).apply {
            text = "یک نماد یا چند نماد را با ویرگول جدا کن. اگر کادر خالی باشد، کل بازار بررسی می‌شود."
            textSize = 15f
            setTextColor(0xFF42526E.toInt())
            setPadding(0, 0, 0, 12)
        }
        layout.addView(explanation)

        symbolsInput = EditText(this).apply {
            hint = "مثلاً فولاد، فملی، شتبریز (اختیاری)"
            textSize = 16f
            singleLine = true
            textDirection = View.TEXT_DIRECTION_RTL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        layout.addView(symbolsInput, LinearLayout.LayoutParams(-1, -2))

        val periodLabel = TextView(this).apply {
            text = "بازه بررسی"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF172B4D.toInt())
            setPadding(0, 18, 0, 8)
        }
        layout.addView(periodLabel)

        periodSpinner = Spinner(this)
        val periods = listOf("یک ماه", "سه ماه", "شش ماه", "یک سال")
        periodSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, periods)
        periodSpinner.setSelection(3)
        layout.addView(periodSpinner)

        runButton = Button(this).apply {
            text = "شروع تحلیل"
            textSize = 16f
            setOnClickListener { startAnalysis() }
        }
        val buttonParams = LinearLayout.LayoutParams(-1, -2)
        buttonParams.topMargin = 20
        layout.addView(runButton, buttonParams)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
            isIndeterminate = true
        }
        layout.addView(progress, LinearLayout.LayoutParams(-1, 12))

        statusView = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF526581.toInt())
            setPadding(0, 12, 0, 8)
        }
        layout.addView(statusView)

        resultView = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFF172B4D.toInt())
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFFFFFFFF.toInt())
            textDirection = View.TEXT_DIRECTION_RTL
            setTextIsSelectable(true)
        }
        val resultParams = LinearLayout.LayoutParams(-1, -2)
        resultParams.topMargin = 10
        layout.addView(resultView, resultParams)

        val foot = TextView(this).apply {
            text = "توجه: داده‌ها از سرویس عمومی TSETMC دریافت می‌شوند. دسترسی ممکن است بسته به اینترنت یا محدودیت سرور برقرار نباشد. این گزارش توصیه قطعی خرید و فروش نیست."
            textSize = 12f
            setTextColor(0xFF6B778C.toInt())
            setPadding(0, 18, 0, 10)
        }
        layout.addView(foot)

        scroll.addView(layout)
        setContentView(scroll)
    }

    private fun startAnalysis() {
        val symbols = symbolsInput.text.toString().split(",", "،")
            .map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        val periodDays = when (periodSpinner.selectedItemPosition) {
            0 -> 31
            1 -> 93
            2 -> 186
            else -> 366
        }
        runButton.isEnabled = false
        progress.visibility = View.VISIBLE
        resultView.text = ""
        statusView.text = "در حال دریافت اطلاعات از TSETMC ..."
        executor.execute {
            try {
                val end = LocalDate.now()
                val start = end.minusDays(periodDays.toLong())
                val data = if (symbols.isEmpty()) {
                    fetchWholeMarket(start, end)
                } else {
                    fetchSelectedSymbols(symbols, start, end)
                }
                val report = makeReport(data, symbols.isEmpty(), start, end)
                runOnUiThread {
                    resultView.text = report
                    statusView.text = "دریافت ${data.size} رکورد قیمت پایان یافت."
                    runButton.isEnabled = true
                    progress.visibility = View.GONE
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusView.text = "خطا در دریافت اطلاعات"
                    resultView.text = "امکان دریافت یا پردازش داده‌ها وجود نداشت.\n\n${e.message ?: "خطای نامشخص"}\n\nلطفاً اتصال اینترنت را بررسی کن و دوباره تلاش کن. ممکن است سرویس TSETMC از بعضی شبکه‌ها پاسخ ندهد."
                    runButton.isEnabled = true
                    progress.visibility = View.GONE
                }
            }
        }
    }

    private fun httpGet(path: String): JSONObject {
        val conn = (URL("https://cdn.tsetmc.com/api/$path").openConnection() as HttpURLConnection)
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.requestMethod = "GET"
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        conn.setRequestProperty("Accept", "application/json")
        try {
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchSelectedSymbols(symbols: List<String>, start: LocalDate, end: LocalDate): List<QuoteDay> {
        val all = mutableListOf<QuoteDay>()
        for (symbol in symbols) {
            val encoded = URLEncoder.encode(symbol, "UTF-8").replace("+", "%20")
            val search = httpGet("Instrument/GetInstrumentSearch/$encoded")
            val matches = findArray(search, "instrumentSearch")
                ?: throw Exception("نماد $symbol در پاسخ جست‌وجو پیدا نشد.")
            var insCode: String? = null
            var actualSymbol = symbol
            for (i in 0 until matches.length()) {
                val item = matches.optJSONObject(i) ?: continue
                val name = item.optString("lVal18AFC", item.optString("symbol", ""))
                if (name == symbol || insCode == null) {
                    insCode = item.optString("insCode").takeIf { it.isNotBlank() }
                    if (name.isNotBlank()) actualSymbol = name
                    if (name == symbol) break
                }
            }
            val code = insCode ?: throw Exception("کد معاملاتی نماد $symbol پیدا نشد.")
            val history = httpGet("ClosingPrice/GetClosingPriceDailyList/$code/0")
            val rows = findArray(history, "closingPriceDaily")
                ?: throw Exception("تاریخچه قیمت نماد $symbol دریافت نشد.")
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                val date = parseDate(row.optString("dEven")) ?: continue
                if (date.isBefore(start) || date.isAfter(end)) continue
                val close = row.optDouble("pClosing", Double.NaN)
                val prev = row.optDouble("priceYesterday", Double.NaN)
                if (close.isFinite() && prev.isFinite() && prev > 0) {
                    all.add(QuoteDay(date, actualSymbol, close, prev))
                }
            }
            Thread.sleep(500)
        }
        return all
    }

    private fun fetchWholeMarket(start: LocalDate, end: LocalDate): List<QuoteDay> {
        val all = mutableListOf<QuoteDay>()
        var date = start
        val fmt = DateTimeFormatter.BASIC_ISO_DATE
        var checked = 0
        while (!date.isAfter(end)) {
            if (date.dayOfWeek in weekdayOrder.keys) {
                val dateString = date.format(fmt)
                try {
                    val json = httpGet("ClosingPrice/GetInstrmentsHistoryInDay/$dateString")
                    val rows = findArray(json, "closingPriceDailyHistoryWithInstDetails")
                    if (rows != null) {
                        for (i in 0 until rows.length()) {
                            val item = rows.optJSONObject(i) ?: continue
                            val symbol = findString(item, listOf("lVal18AFC", "symbol")) ?: continue
                            val code = findString(item, listOf("insCode")) ?: continue
                            val isin = findString(item, listOf("cIsin")) ?: ""
                            if (!(isin.startsWith("IRO1") || isin.startsWith("IRO5"))) continue
                            val close = findNumber(item, listOf("pClosing")) ?: continue
                            val prev = findNumber(item, listOf("priceYesterday")) ?: continue
                            if (prev > 0) all.add(QuoteDay(date, symbol, close, prev))
                        }
                    }
                } catch (_: Exception) {
                    // بازار در تعطیلی رسمی ممکن است داده نداشته باشد؛ روز بعد ادامه می‌دهیم.
                }
                checked++
                val progressText = "بررسی روزهای معاملاتی: $checked (ممکن است چند دقیقه طول بکشد)"
                runOnUiThread { statusView.text = progressText }
                Thread.sleep(450)
            }
            date = date.plusDays(1)
        }
        if (all.isEmpty()) throw Exception("از تاریخچه کل بازار داده‌ای دریافت نشد. ممکن است API این endpoint را محدود کرده یا ساختار پاسخ تغییر کرده باشد.")
        return all
    }

    private fun findArray(obj: JSONObject, key: String): JSONArray? {
        if (obj.has(key) && obj.opt(key) is JSONArray) return obj.optJSONArray(key)
        val keys = obj.keys()
        while (keys.hasNext()) {
            val value = obj.opt(keys.next())
            if (value is JSONObject) findArray(value, key)?.let { return it }
            if (value is JSONArray) {
                for (i in 0 until value.length()) {
                    val child = value.opt(i)
                    if (child is JSONObject) findArray(child, key)?.let { return it }
                }
            }
        }
        return null
    }

    private fun findString(obj: JSONObject, names: List<String>): String? {
        for (name in names) {
            val v = obj.opt(name)
            if (v != null && v != JSONObject.NULL && v !is JSONObject && v !is JSONArray) {
                val s = v.toString()
                if (s.isNotBlank() && s != "0") return s
            }
        }
        val keys = obj.keys()
        while (keys.hasNext()) {
            val v = obj.opt(keys.next())
            if (v is JSONObject) findString(v, names)?.let { return it }
        }
        return null
    }

    private fun findNumber(obj: JSONObject, names: List<String>): Double? {
        for (name in names) {
            val v = obj.opt(name)
            val d = when (v) {
                is Number -> v.toDouble()
                is String -> v.toDoubleOrNull()
                else -> null
            }
            if (d != null && d > 0) return d
        }
        val keys = obj.keys()
        while (keys.hasNext()) {
            val v = obj.opt(keys.next())
            if (v is JSONObject) findNumber(v, names)?.let { return it }
        }
        return null
    }

    private fun parseDate(raw: String): LocalDate? {
        return try {
            val s = raw.take(8)
            LocalDate.parse(s, DateTimeFormatter.BASIC_ISO_DATE)
        } catch (_: Exception) { null }
    }

    private fun makeReport(data: List<QuoteDay>, wholeMarket: Boolean, start: LocalDate, end: LocalDate): String {
        if (data.isEmpty()) return "برای بازه انتخاب‌شده داده‌ای پیدا نشد."
        val grouped = data.filter { weekdayOrder.containsKey(it.date.dayOfWeek) }
            .groupBy { weekdayOrder[it.date.dayOfWeek]!! }
        val lines = mutableListOf<String>()
        lines += if (wholeMarket) "گزارش کل بازار سهام" else "گزارش نماد(های) انتخاب‌شده"
        lines += "بازه: ${start} تا ${end}"
        lines += "تعداد رکوردهای قیمت: ${data.size}"
        lines += ""
        lines += "روز هفته | میانگین بازده | میانه بازده | درصد نمادهای منفی"
        lines += "-----------------------------------------------"
        val stats = mutableListOf<Triple<Int, Double, Double>>()
        for (idx in 0..4) {
            val rows = grouped[idx] ?: continue
            val returns = rows.map { it.ret }.sorted()
            val mean = returns.average()
            val median = if (returns.size % 2 == 1) returns[returns.size / 2]
                else (returns[returns.size / 2 - 1] + returns[returns.size / 2]) / 2.0
            val negative = rows.count { it.ret < 0 }.toDouble() * 100.0 / rows.size
            stats += Triple(idx, median, negative)
            lines += "${weekdays[idx]} | ${format(mean)}٪ | ${format(median)}٪ | ${format(negative)}٪"
        }
        lines += ""
        val cheapest = stats.minByOrNull { it.second }
        val mostNegative = stats.maxByOrNull { it.third }
        val best = stats.maxByOrNull { it.second }
        if (cheapest != null) lines += "کمترین میانه بازده (روز با فشار نزولی بیشتر): ${weekdays[cheapest.first]}"
        if (mostNegative != null) lines += "بیشترین درصد نمادهای منفی: ${weekdays[mostNegative.first]}"
        if (best != null) lines += "بیشترین میانه بازده: ${weekdays[best.first]}"
        lines += ""
        lines += "تفسیر: روزی که بازده منفی‌تری دارد لزوماً قیمت خرید پایین‌تری برای همه سهم‌ها ایجاد نمی‌کند. برای نتیجه معاملاتی باید روند، نقدشوندگی، توقف نماد و هزینه معامله نیز بررسی شود."
        lines += ""
        lines += "محدودیت: بازده این نسخه از قیمت پایانی نسبت به قیمت پایانی روز قبل محاسبه شده و تعدیلات افزایش سرمایه/سود نقدی به‌طور مستقل اعمال نشده است؛ بنابراین اطراف رویدادهای شرکتی با احتیاط تفسیر شود."
        return lines.joinToString("\n")
    }

    private fun format(value: Double): String =
        String.format(Locale.US, "%.3f", value)
}
